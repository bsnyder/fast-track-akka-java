# TODO

Slide deck for the *TODO* training course from Typesafe.

## License

Copyright 2014 Typesafe, Inc. All rights reserved.

Unless otherwise agreed, training materials may only be used for educational and reference purposes by individual named participants in a training course offered by Typesafe or a Typesafe training partner. Unauthorized reproduction, redistribution, or use of this material is prohibited.
